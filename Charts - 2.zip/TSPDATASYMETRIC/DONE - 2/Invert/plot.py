import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "2n" : loadCSV("2n.csv"),
    "n" : loadCSV("n.csv"),
    "n2" : loadCSV("n2.csv"),
    "n3" : loadCSV("n3.csv"),
    "n4" : loadCSV("n4.csv"),
    "n5" : loadCSV("n5.csv"),
    "n10" : loadCSV("n10.csv"),
    "7" : loadCSV("7.csv")
}

ax = algorithms["2n"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="2n", x='n', y='prd')
algorithms["n"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n", x='n', y='prd')
algorithms["n2"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n/2", x='n', y='prd')
algorithms["n3"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n/3", x='n', y='prd')
algorithms["n4"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n/4", x='n', y='prd')
algorithms["n5"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n/5", x='n', y='prd')
algorithms["n10"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="n/10", x='n', y='prd')
algorithms["7"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="7", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()