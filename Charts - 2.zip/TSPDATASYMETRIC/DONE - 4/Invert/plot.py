import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

filepaths = ["a280.xml.out", "att48.xml.out", "berlin52.xml.out", "bier127.xml.out", "brazil58.xml.out", "dsj1000.xml.out"]
prds = [2579, 10628, 7542, 118282, 25395, 18660188]

for i in range(len(filepaths)):
    filepath = filepaths[i]
    prd = prds[i]
    
    df = pd.read_csv(filepath, header=None, delimiter=";", names=["algorithm", "prd", "iteration", "time"])
    df = (df.groupby(by=["algorithm", "prd", "iteration"])["time"].agg([("time_avg", "median")]).reset_index())
    df["prd"] = (df["prd"] - prd) / prd

    title = "PRD(Time [ns]) - Invert Neighborhoood - " + filepath
    ax = df.loc[df["algorithm"]==0].plot.scatter(legend=True, title=title, label="Invert", x = "time_avg", y = "prd", c="Blue")
    df.loc[df["algorithm"]==1].plot.scatter(ax = ax, legend=True, title=title, label="AcceleratedInvert", x = "time_avg", y = "prd", c="Orange")
    df.loc[df["algorithm"]==2].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedInvert", x = "time_avg", y = "prd", c="Red")
    df.loc[df["algorithm"]==3].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedAcceleratedInvert", x = "time_avg", y = "prd", c="Black")
    plt.savefig("plots/" + filepath + "-prd-time_avg.png")
    plt.figure()
    
    title = "Iterations(Time [ns]) - Invert Neighborhoood - " + filepath
    ax = df.loc[df["algorithm"]==0].plot.scatter(legend=True, title=title, label="Invert", x = "time_avg", y = "iteration", c="Blue")
    df.loc[df["algorithm"]==1].plot.scatter(ax = ax, legend=True, title=title, label="AcceleratedInvert", x = "time_avg", y = "iteration", c="Orange")
    df.loc[df["algorithm"]==2].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedInvert", x = "time_avg", y = "iteration", c="Red")
    df.loc[df["algorithm"]==3].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedAcceleratedInvert", x = "time_avg", y = "iteration", c="Black")
    plt.savefig("plots/" + filepath + "-iterations-time_avg.png")
    plt.figure()
    
    title = "Time(Iterations) [ns]- Invert Neighborhoood - " + filepath
    ax = df.loc[df["algorithm"]==0].plot.scatter(legend=True, title=title, label="Invert", x = "iteration", y = "time_avg", c="Blue")
    df.loc[df["algorithm"]==1].plot.scatter(ax = ax, legend=True, title=title, label="AcceleratedInvert", x = "iteration", y = "time_avg", c="Orange")
    df.loc[df["algorithm"]==2].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedInvert", x = "iteration", y = "time_avg", c="Red")
    df.loc[df["algorithm"]==3].plot.scatter(ax = ax, legend=True, title=title, label="MultithreadedAcceleratedInvert", x = "iteration", y = "time_avg", c="Black")
    plt.savefig("plots/" + filepath + "-time_avg-iterations.png")
    plt.figure()