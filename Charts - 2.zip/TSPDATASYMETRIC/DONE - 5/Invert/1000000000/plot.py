import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

filepaths = ["a280.xml.out", "att48.xml.out", "berlin52.xml.out", "bier127.xml.out", "brazil58.xml.out"]
prds = [2579, 10628, 7542, 118282, 25395]

for i in range(len(filepaths)):
    filepath = filepaths[i]
    prd = prds[i]
    
    df = pd.read_csv(filepath, header=None, delimiter=";", names=["algorithm", "prd", "iteration", "time"])
    df["prd"] = (df["prd"] - prd) / prd
    df = (df.groupby(by=["algorithm"])["prd"].agg([("prd_avg", "median")]).reset_index())
    
    df.plot.scatter(legend=True, title="PRD (stagnation parameter)", label="AcceleratedInvertMultithreaded", x = "algorithm", y = "prd_avg", c="Blue")
    plt.savefig("plots/" + filepath + "-stagnation-prd.png")
    plt.figure()
