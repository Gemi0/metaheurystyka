import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

filepaths = ["a280.xml.out", "att48.xml.out", "berlin52.xml.out", "bier127.xml.out", "brazil58.xml.out"]
prds = [2579, 10628, 7542, 118282, 25395]

for i in range(len(filepaths)):
    filepath = filepaths[i]
    prd = prds[i]
    
    df = pd.read_csv(filepath, header=None, delimiter=";", names=["algorithm", "prd", "iteration", "time"])
    df = (df.groupby(by=["algorithm", "prd", "iteration"])["time"].agg([("time_avg", "median")]).reset_index())
    df["prd"] = (df["prd"] - prd) / prd
    
    title = "PRD(iterations) - Swap Neighborhoood - " + filepath
    ax = df.loc[df["algorithm"]==0].plot.scatter(legend=True, title=title, label="(1,2,3, ...)", x = "iteration", y = "prd", c="Blue")
    df.loc[df["algorithm"]==1].plot.scatter(ax = ax, legend=True, title=title, label="NeighborExtended", x = "iteration", y = "prd", c="Orange")
    df.loc[df["algorithm"]==2].plot.scatter(ax = ax, legend=True, title=title, label="2OPT", x = "iteration", y = "prd", c="Red")
    plt.savefig("plots/" + filepath + "-iterations.png")
    plt.figure()

    title = "PRD(Time [ns]) - Swap Neighborhoood - " + filepath
    ax = df.loc[df["algorithm"]==0].plot.scatter(legend=True, title=title, label="(1,2,3, ...)", x = "time_avg", y = "prd", c="Blue")
    df.loc[df["algorithm"]==1].plot.scatter(ax = ax, legend=True, title=title, label="NeighborExtended", x = "time_avg", y = "prd", c="Orange")
    df.loc[df["algorithm"]==2].plot.scatter(ax = ax, legend=True, title=title, label="2OPT", x = "time_avg", y = "prd", c="Red")
    plt.savefig("plots/" + filepath + "-time_avg.png")
    plt.figure()