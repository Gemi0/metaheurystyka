import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "no-stagnation-no-aspiration" : loadCSV("no-stagnation-no-aspiration.csv"),
    "no-stagnation-yes-aspiration" : loadCSV("no-stagnation-yes-aspiration.csv"),
    "yes-stagnation-no-aspiration" : loadCSV("yes-stagnation-no-aspiration.csv"),
    "yes-stagnation-yes-aspiration" : loadCSV("yes-stagnation-yes-aspiration.csv")
}

ax = algorithms["no-stagnation-no-aspiration"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="no-stagnation-no-aspiration", x='n', y='prd')
algorithms["no-stagnation-yes-aspiration"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="no-stagnation-yes-aspiration", x='n', y='prd')
algorithms["yes-stagnation-no-aspiration"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | navg. from 10 samples", label="yes-stagnation-no-aspiration", x='n', y='prd')
algorithms["yes-stagnation-yes-aspiration"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | navg. from 10 samples", label="yes-stagnation-yes-aspiration", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()