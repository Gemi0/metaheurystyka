import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["name", "time", "prd"])

#PATH
problems = {
    "ftv33" : loadCSV("ftv33.csv"),
    "ftv35" : loadCSV("ftv35.csv"),
    "ftv38" : loadCSV("ftv38.csv"),
    "ftv44" : loadCSV("ftv44.csv"),
    "ftv47" : loadCSV("ftv47.csv"),
    "ftv170" : loadCSV("ftv170.csv"),
}

for problem in problems:
    problems[problem].plot.bar(rot = 0, x = "name", y = "time", legend=True, title="Time(n) [ns]\navg. from 10 samples")
    plt.savefig("time-"+problem+".png")
plt.figure()

for problem in problems:
    problems[problem].plot.bar(rot = 0, x = "name", y = "prd", legend=True, title="PRD(n)\nfrom TSPLib data | avg. from 10 samples")
    plt.savefig("prd-"+problem+".png")
plt.figure()

for problem in problems:
    problems[problem] = problems[problem].drop([0])
    problems[problem].plot.bar(rot = 0, x = "name", y = "prd", legend=True, title="PRD(n)\nfrom TSPLib data | avg. from 10 samples")
    plt.savefig("prd-without-k-random-"+problem+".png")
plt.figure()

