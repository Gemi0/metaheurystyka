import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "kRandom-100" : loadCSV("kRandom-100.csv"),
    "kRandom-1000" : loadCSV("kRandom-1000.csv"),
    "kRandom-10000" : loadCSV("kRandom-10000.csv"),
    "kRandom-100000" : loadCSV("kRandom-100000.csv")
}

ax = algorithms["kRandom-100"].plot(legend=True, title="Time(n) [ns]\navg. from 50 samples", label="kRandom-100", x='n', y='time')
algorithms["kRandom-1000"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="kRandom-1000", x='n', y='time')
algorithms["kRandom-10000"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="kRandom-10000", x='n', y='time')
algorithms["kRandom-100000"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="kRandom-100000", x='n', y='time')
plt.savefig("time.png")
plt.figure()

ax = algorithms["kRandom-100"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="kRandom-100", x='n', y='prd')
algorithms["kRandom-1000"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="kRandom-1000", x='n', y='prd')
algorithms["kRandom-10000"].plot(ax=ax, legend=True, title="PRD(n)\from best result | navg. from 50 samples", label="kRandom-10000", x='n', y='prd')
algorithms["kRandom-100000"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="kRandom-100000", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()