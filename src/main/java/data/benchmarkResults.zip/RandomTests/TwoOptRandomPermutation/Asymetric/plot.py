import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "twoOpt1" : loadCSV("twoOpt1.csv"),
    "twoOpt-1" : loadCSV("twoOpt-1.csv"),
    "twoOptRand" : loadCSV("twoOptRand.csv")
}

ax = algorithms["twoOpt1"].plot(legend=True, title="Time(n) [ns]\navg. from 10 samples", label="twoOpt1", x='n', y='time')
algorithms["twoOpt-1"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 10 samples", label="twoOpt-1", x='n', y='time')
algorithms["twoOptRand"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 10 samples", label="twoOptRand", x='n', y='time')
plt.savefig("time.png")
plt.figure()

ax = algorithms["twoOpt1"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="twoOpt1", x='n', y='prd')
algorithms["twoOpt-1"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="twoOpt-1", x='n', y='prd')
algorithms["twoOptRand"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | navg. from 10 samples", label="twoOptRand", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()