import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "kRandom-10000" : loadCSV("kRandom-10000.csv"),
    "neighbor" : loadCSV("neighbor.csv"),
    "neighborExtended" : loadCSV("neighborExtended.csv"),
    "twoOpt" : loadCSV("twoOpt.csv"),
    "acceleratedTwoOpt" : loadCSV("acceleratedTwoOpt.csv"),
}

#ax = algorithms["kRandom-10000"].plot(legend=True, title="Time(n) [ns]\navg. from 50 samples", label="kRandom-10000", x='n', y='time')
#algorithms["neighbor"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="neighbor", x='n', y='time')
#algorithms["neighborExtended"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="neighborExtended", x='n', y='time')
#algorithms["twoOpt"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="twoOpt", x='n', y='time')
#algorithms["acceleratedTwoOpt"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 50 samples", label="acceleratedTwoOpt", x='n', y='time')
#plt.savefig("time.png")
#plt.figure()

#ax = algorithms["kRandom-10000"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="kRandom-10000", x='n', y='prd')
ax = algorithms["neighbor"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="neighbor", x='n', y='prd')
algorithms["neighborExtended"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | navg. from 50 samples", label="neighborExtended", x='n', y='prd')
algorithms["twoOpt"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="twoOpt", x='n', y='prd')
algorithms["acceleratedTwoOpt"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 50 samples", label="acceleratedTwoOpt", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()