import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "neighbor" : loadCSV("neighbor.csv")
}

algorithms["neighbor"].plot(legend=True, title="Time(n) [ns]\navg. from 50 samples", label="neighbor", x='n', y='time')
plt.savefig("time.png")
plt.figure()