import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

def loadCSV(path):
    return pd.read_csv(path, header=None, delimiter=";", names=["n", "time", "prd"])

#PATH
algorithms = {
    "neighborExtended" : loadCSV("neighborExtended.csv"),
    "twoOpt" : loadCSV("twoOpt.csv"),
    "twoOptExtended" : loadCSV("twoOptExtended.csv")
}

ax = algorithms["neighborExtended"].plot(legend=True, title="Time(n) [ns]\navg. from 10 samples", label="neighborExtended", x='n', y='time')
algorithms["twoOpt"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 10 samples", label="twoOpt", x='n', y='time')
algorithms["twoOptExtended"].plot(ax=ax, legend=True, title="Time(n) [ns]\navg. from 10 samples", label="twoOptExtended", x='n', y='time')
plt.savefig("time.png")
plt.figure()

ax = algorithms["neighborExtended"].plot(legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="neighborExtended", x='n', y='prd')
algorithms["twoOpt"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | avg. from 10 samples", label="twoOpt", x='n', y='prd')
algorithms["twoOptExtended"].plot(ax=ax, legend=True, title="PRD(n)\nfrom best result | navg. from 10 samples", label="twoOptExtended", x='n', y='prd')
plt.savefig("prd.png")
plt.figure()